from flask import Flask, request, render_template, jsonify
import os
import torch
from models import custom_models_ctnet
from load_dataset import utils
import numpy as np

app = Flask(__name__)

# Initialize model
def load_model(model_path, n_outputs=83):
    model = custom_models_ctnet.CTNetModel(n_outputs=n_outputs)
    if os.path.exists(model_path):
        model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    model.eval()
    return model

# Global variables
MODEL_PATH = 'model_weights/ctnet83_weights.pth'  # Use forward slashes

# Complete list of 83 labels from the dataset files
LABEL_MEANINGS = [
    'bandlike_or_linear', 'bronchial_wall_thickening', 'groundglass', 
    'honeycombing', 'reticulation', 'tree_in_bud', 'airspace_disease',
    'air_trapping', 'aspiration', 'atelectasis', 'bronchiectasis',
    'bronchiolectasis', 'bronchiolitis', 'bronchitis', 'emphysema',
    'hemothorax', 'interstitial_lung_disease', 'lung_resection',
    'mucous_plugging', 'pleural_effusion', 'pleural_thickening',
    'pneumonia', 'pneumonitis', 'pneumothorax', 'pulmonary_edema',
    'septal_thickening', 'tuberculosis', 'cabg', 'cardiomegaly',
    'coronary_artery_disease', 'heart_failure', 'heart_valve_replacement',
    'pacemaker_or_defib', 'pericardial_effusion', 'pericardial_thickening',
    'sternotomy', 'arthritis', 'atherosclerosis', 'aneurysm',
    'breast_implant', 'breast_surgery', 'calcification', 'cancer',
    'catheter_or_port', 'cavitation', 'clip', 'congestion',
    'consolidation', 'cyst', 'debris', 'deformity', 'density',
    'dilation_or_ectasia', 'distention', 'fibrosis', 'fracture',
    'granuloma', 'hardware', 'hernia', 'infection', 'infiltrate',
    'inflammation', 'lesion', 'lucency', 'lymphadenopathy', 'mass',
    'nodule', 'nodulegr1cm', 'opacity', 'plaque', 'postsurgical',
    'scarring', 'scattered_calc', 'scattered_nod', 'secretion',
    'soft_tissue', 'staple', 'stent', 'suture', 'transplant',
    'chest_tube', 'tracheal_tube', 'gi_tube'
]

model = load_model(MODEL_PATH)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get uploaded file
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'})
        
        if not file.filename.endswith('.npz'):
            return jsonify({'error': 'Please upload a .npz file'})

        # Load CT volume - the project uses .npz files with 'ct' as the key
        try:
            # Save temporarily to handle npz file
            temp_path = os.path.join('static', 'temp.npz')
            file.save(temp_path)
            ctvol = np.load(temp_path)['ct']
            os.remove(temp_path)  # Clean up
        except Exception as e:
            return jsonify({'error': f'Error loading CT volume: {str(e)}'})

        # Validate volume dimensions
        if len(ctvol.shape) != 3:
            return jsonify({'error': 'Invalid CT volume format - expected 3D array'})

        # Preprocess using existing utils
        try:
            processed_vol = utils.prepare_ctvol_2019_10_dataset(
                ctvol=ctvol,
                pixel_bounds=[-1000, 200],  # HU window from the paper
                data_augment=False,
                num_channels=3,
                crop_type='single'
            )
        except Exception as e:
            return jsonify({'error': f'Error in preprocessing: {str(e)}'})

        # Make prediction
        try:
            with torch.no_grad():
                outputs = model(processed_vol.unsqueeze(0))
                probs = torch.sigmoid(outputs).numpy()[0]
        except Exception as e:
            return jsonify({'error': f'Error in model prediction: {str(e)}'})

        # Format results - include all predictions sorted by probability
        results = []
        for label, prob in zip(LABEL_MEANINGS, probs):
            results.append({
                'label': label,
                'probability': float(prob)
            })
        
        # Sort by probability descending
        results.sort(key=lambda x: x['probability'], reverse=True)

        # Only return findings with >10% probability to reduce noise
        results = [r for r in results if r['probability'] > 0.1]

        return jsonify({
            'success': True,
            'predictions': results
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

if __name__ == '__main__':
    # Create static directory if it doesn't exist
    os.makedirs('static', exist_ok=True)
    app.run(debug=True, port=5000) 