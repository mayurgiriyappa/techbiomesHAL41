import os

def create_directory_structure():
    # Create directories if they don't exist
    directories = [
        'templates',
        'static',
        'models/pretrained'
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)

if __name__ == '__main__':
    create_directory_structure() 